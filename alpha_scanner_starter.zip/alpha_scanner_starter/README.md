# 台股 Alpha Scanner（私人自用原型）

## 這個版本能做什麼
- 匯入分鐘 K CSV（1 分鐘或 5 分鐘資料）
- 依股票、交易日整理成 60 分鐘 K
- 計算 5MA / 20MA（可在側邊欄調整）
- 找出最近 N 根 60 分鐘 K 內剛發生黃金交叉、且短均線仍在長均線之上的股票
- 檢查成交量相對前 5 根均量、上影線比例及單根漲幅
- 匯出候選清單

## CSV 格式
必須有以下欄位（中文欄位也支援部分常見名稱）：
`stock_id, datetime, open, high, low, close, volume`

每檔股票最好有至少 25 根以上完整 60 分鐘 K，若要穩定計算 20MA，建議匯入至少 20 個交易時段的資料。

## 本版本限制
- 目前不是即時行情爬蟲，也不會自動掃描全市場。
- 需要你從有權使用的行情來源匯出分鐘 K CSV 再上傳。
- 重採樣以 09:00 為起點，每日分開計算；不同券商匯出的時間戳記、盤中休市或缺漏資料可能造成 K 棒邊界差異，請先核對。
- 量比、上影線與漲幅門檻是初始研究參數，必須回測後再調整。
- 不構成投資建議。

## 本機執行
1. 安裝 Python 3.10 或以上版本。
2. 解壓縮本專案。
3. 在專案資料夾執行：
   ```bash
   pip install -r requirements.txt
   streamlit run app.py
   ```
4. 瀏覽器開啟 Streamlit 顯示的網址。

## 免費部署
可將 `app.py` 與 `requirements.txt` 放進 GitHub repository，再到 Streamlit Community Cloud 建立 App。
若未來加入 API token，請放在 Streamlit Secrets，不要寫進程式碼或公開 GitHub。
