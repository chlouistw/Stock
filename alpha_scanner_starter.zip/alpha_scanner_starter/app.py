import streamlit as st
import pandas as pd
import numpy as np
from io import BytesIO

st.set_page_config(page_title="台股 Alpha Scanner", page_icon="📈", layout="wide")

st.title("📈 台股 Alpha Scanner")
st.caption("私人自用技術選股原型｜匯入分鐘 K CSV，整理 60 分鐘 K 並掃描均線轉強訊號")

with st.sidebar:
    st.header("掃描設定")
    fast_n = st.number_input("短均線", min_value=2, max_value=20, value=5)
    slow_n = st.number_input("長均線", min_value=5, max_value=60, value=20)
    vol_ratio_min = st.slider("成交量放大門檻（相對前 5 根均量）", 0.5, 3.0, 1.3, 0.1)
    wick_max = st.slider("上影線比例上限", 0.05, 0.8, 0.35, 0.05)
    max_day_gain = st.slider("排除當日漲幅超過（%）", 1, 10, 5)
    cross_window = st.number_input("最近幾根 60 分 K 內發生交叉", min_value=1, max_value=10, value=2)

st.info(
    "資料格式：CSV 至少要有 stock_id、datetime、open、high、low、close、volume。"
    "可匯入 1 分鐘或 5 分鐘歷史 K；每檔股票最好有至少 25 根以上完整 60 分鐘 K。"
)

uploaded = st.file_uploader("上傳分鐘 K CSV", type=["csv"])

def normalize_columns(df):
    aliases = {
        "股票代號": "stock_id", "代號": "stock_id", "證券代號": "stock_id",
        "時間": "datetime", "日期時間": "datetime", "date": "datetime",
        "日期": "datetime", "開盤": "open", "開": "open",
        "最高": "high", "高": "high", "最低": "low", "低": "low",
        "收盤": "close", "收": "close", "成交量": "volume", "量": "volume"
    }
    df = df.rename(columns={c: aliases.get(str(c).strip(), str(c).strip().lower()) for c in df.columns})
    return df

def make_60m(df):
    required = ["stock_id", "datetime", "open", "high", "low", "close", "volume"]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError("缺少欄位：" + ", ".join(missing))
    df = df[required].copy()
    df["stock_id"] = df["stock_id"].astype(str).str.strip()
    df["datetime"] = pd.to_datetime(df["datetime"], errors="coerce")
    for c in ["open", "high", "low", "close", "volume"]:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    df = df.dropna(subset=required).sort_values(["stock_id", "datetime"])
    results = []
    # 台股一般交易時段 09:00–13:30；以每個交易日為單位重採樣，避免跨日混合
    df["trade_date"] = df["datetime"].dt.date
    for (sid, day), g in df.groupby(["stock_id", "trade_date"]):
        g = g.set_index("datetime").sort_index()
        # 以 09:00 為起點分組；最後不足一小時的區段保留
        bars = g.resample("60min", origin="start_day", offset="9h", label="right", closed="right").agg(
            open=("open", "first"), high=("high", "max"), low=("low", "min"),
            close=("close", "last"), volume=("volume", "sum")
        ).dropna(subset=["open", "high", "low", "close"])
        if not bars.empty:
            bars["stock_id"] = sid
            results.append(bars.reset_index())
    if not results:
        return pd.DataFrame()
    out = pd.concat(results, ignore_index=True)
    return out.sort_values(["stock_id", "datetime"])

def scan_one(g):
    g = g.sort_values("datetime").copy()
    g["ma_fast"] = g["close"].rolling(int(fast_n)).mean()
    g["ma_slow"] = g["close"].rolling(int(slow_n)).mean()
    g["vol_avg5"] = g["volume"].shift(1).rolling(5).mean()
    prev = g.shift(1)
    g["cross_up"] = (prev["ma_fast"] <= prev["ma_slow"]) & (g["ma_fast"] > g["ma_slow"])
    # 上影線比例： (high - max(open, close)) / (high - low)
    spread = (g["high"] - g["low"]).replace(0, np.nan)
    g["upper_wick_ratio"] = (g["high"] - g[["open", "close"]].max(axis=1)) / spread
    g["vol_ratio"] = g["volume"] / g["vol_avg5"].replace(0, np.nan)
    g["bar_return_pct"] = (g["close"] / g["open"] - 1) * 100
    g["cross_recent"] = g["cross_up"].rolling(int(cross_window), min_periods=1).max().astype(bool)
    latest = g.iloc[-1]
    # 若最近 N 根有交叉，仍需目前短均線在長均線之上
    is_candidate = bool(latest["cross_recent"]) and latest["ma_fast"] > latest["ma_slow"]
    if not is_candidate:
        return None
    volume_ok = pd.notna(latest["vol_ratio"]) and latest["vol_ratio"] >= vol_ratio_min
    wick_ok = pd.notna(latest["upper_wick_ratio"]) and latest["upper_wick_ratio"] <= wick_max
    gain_ok = latest["bar_return_pct"] <= max_day_gain
    score = 60
    score += 15 if volume_ok else 0
    score += 15 if wick_ok else 0
    score += 10 if gain_ok else 0
    return {
        "股票代號": latest["stock_id"],
        "最新60分K時間": latest["datetime"],
        "收盤價": round(float(latest["close"]), 2),
        f"{fast_n}MA": round(float(latest["ma_fast"]), 2),
        f"{slow_n}MA": round(float(latest["ma_slow"]), 2),
        "量比": round(float(latest["vol_ratio"]), 2) if pd.notna(latest["vol_ratio"]) else np.nan,
        "上影線比例": round(float(latest["upper_wick_ratio"]), 2) if pd.notna(latest["upper_wick_ratio"]) else np.nan,
        "單根漲幅(%)": round(float(latest["bar_return_pct"]), 2),
        "量能合格": "是" if volume_ok else "否",
        "上影線合格": "是" if wick_ok else "否",
        "評分": score
    }

if uploaded:
    try:
        raw = pd.read_csv(uploaded)
        raw = normalize_columns(raw)
        bars = make_60m(raw)
        if bars.empty:
            st.warning("沒有可用資料，請檢查 CSV。")
        else:
            st.success(f"成功整理 {raw['stock_id'].nunique()} 檔股票、{len(bars):,} 根 60 分鐘 K。")
            results = []
            for sid, group in bars.groupby("stock_id"):
                # 至少要有足夠歷史 K 才能計算長均線
                if len(group) >= int(slow_n) + 1:
                    item = scan_one(group)
                    if item:
                        results.append(item)
            if results:
                out = pd.DataFrame(results).sort_values(["評分", "量比"], ascending=False)
                st.subheader(f"候選股票：{len(out)} 檔")
                st.dataframe(out, use_container_width=True, hide_index=True)
                st.download_button("下載候選清單 CSV", out.to_csv(index=False).encode("utf-8-sig"),
                                   file_name="alpha_candidates.csv", mime="text/csv")
                selected = st.selectbox("查看個股 60 分鐘 K", out["股票代號"].tolist())
                chart = bars[bars["stock_id"] == selected].copy().sort_values("datetime")
                chart["MA短"] = chart["close"].rolling(int(fast_n)).mean()
                chart["MA長"] = chart["close"].rolling(int(slow_n)).mean()
                st.line_chart(chart.set_index("datetime")[["close", "MA短", "MA長"]])
                st.bar_chart(chart.set_index("datetime")[["volume"]])
            else:
                st.warning("目前沒有股票符合均線剛轉強條件。可調整成交量、上影線或交叉窗口。")
            with st.expander("查看整理後的 60 分鐘 K"):
                st.dataframe(bars.tail(100), use_container_width=True, hide_index=True)
    except Exception as e:
        st.error(f"讀取失敗：{e}")
else:
    st.subheader("CSV 欄位範例")
    sample = pd.DataFrame([
        ["2330", "2026-10-30 09:01:00", 1500, 1502, 1499, 1501, 120],
        ["2330", "2026-10-30 09:02:00", 1501, 1503, 1500, 1502, 95],
    ], columns=["stock_id", "datetime", "open", "high", "low", "close", "volume"])
    st.dataframe(sample, use_container_width=True, hide_index=True)
    st.caption("注意：上例僅示範欄位格式，非真實行情。請匯入包含多日歷史資料的分鐘 K CSV。")

st.divider()
st.caption("研究工具，不是投資建議。資料可能延遲、缺漏或因重採樣方式產生差異；正式使用前請先以券商行情核對。")
